/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   render.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rcarpio-mamaratr <rcarpio-mamaratr@stud    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2026/02/13 12:23:18 by rcarpio-mam       #+#    #+#             */
/*   Updated: 2026/02/13 15:58:44 by rcarpio-mam      ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub.h"

// static void	calc_perp_dist(t_dda_data *ray, t_player *p, int height)
// {
// 	if (ray->side == 0)
// 		ray->perp_dist = (ray->map_x - p->x
// 				+ (1 - ray->step_x) / 2.0) / ray->dir_x;
// 	else
// 		ray->perp_dist = (ray->map_y - p->y
// 				+ (1 - ray->step_y) / 2.0) / ray->dir_y;
// 	//!METER ESTO EN EL DDA
// 	// ray->line_height = (int)(height / ray->perp_dist);
// 	// ray->draw_start = -ray->line_height / 2 + height / 2;
// 	// ray->draw_end = ray->line_height / 2 + height / 2;
// 	if (ray->draw_start < 0)
// 		ray->draw_start = 0;
// 	if (ray->draw_end >= height)
// 		ray->draw_end = height - 1;
// }

static void	draw_stripe_loop(t_stripe s, t_data *data, int x, t_dda_data *ray)
{
	while (s.y <= ray->draw_end)
	{
		s.tex_y = (int)s.tex_pos & (TEX_HEIGHT - 1);
		s.tex_pos += s.step;
		s.frame[s.y * data->width + x]
			= s.tex_pixels[s.tex_y * s.tex_pitch + s.tex_x];
		s.y++;
	}
}

static void	draw_stripe(t_data *data, int x , t_dda_data *ray , t_img *tex)
{
	t_stripe	s;

	s.frame = (unsigned int *)data->img.addr;
	s.tex_pixels = (unsigned int *)tex->addr;
	s.tex_pitch = tex->line_length / 4;
	if (ray->side == 0)
		s.wall_x = data->player.y + ray->perpWallDist * ray->rayDirX;
	else
		s.wall_x = data->player.x + ray->perpWallDist * ray->rayDirY;
	s.wall_x -= floor(s.wall_x);
	s.tex_x = (int)(s.wall_x * TEX_WIDTH);
	if ((ray->side == 0 && ray->rayDirX > 0)
		|| (ray->side == 1 && ray->rayDirY < 0))
		s.tex_x = TEX_WIDTH - s.tex_x - 1;
	s.step = 1.0 * TEX_HEIGHT / ray->line_height;
	s.tex_pos = (ray->draw_start - data->height / 2
			+ ray->line_height / 2) * s.step;
	s.y = ray->draw_start;
	draw_stripe_loop(s, data, x, ray);
}


static t_img	*choose_texture(t_data *data, t_dda_data *ray)
{
	if (ray->side == 0)
	{
		if (ray->rayDirX > 0)
			return (&data->textures.images[TEX_EAST]);
		else
			return (&data->textures.images[TEX_WEST]);
	}
	else
	{
		if (ray->rayDirY > 0)
			return (&data->textures.images[TEX_SOUTH]);
		else
			return (&data->textures.images[TEX_NORTH]);
	}
}

static void	clear_frame(t_data *data)
{
	int				x;
	int				y;
	unsigned int	*frame;
	unsigned int	*bg;

	y = 0;
	frame = (unsigned int *)data->img.addr;
	bg = (unsigned int *)data->bgnd.addr;
	while (y < data->height)
	{
		x = 0;
		while (x < data->width)
		{
			frame[y * data->width + x] = bg[y * data->width + x];
			x++;
		}
		y++;
	}
}



int	ft_render_frame(t_data *data)
{
	int		x;
	// t_ray	ray;
	t_img	*tex;

	clear_frame(data);
	x = 0;
	while (x < data->map->m_width)
	{
		// init_ray(&data->player, x, data->width, &ray);
		// perform_dda(data, &ray, &data->player);
		// calc_perp_dist(&data->dda, &data->player, data->height);
		tex = choose_texture(data, &data->dda);
		draw_stripe(data, x , &data->dda, tex );
		x++;
	}
	mlx_put_image_to_window(data->mlx, data->win, data->img.frame, 0, 0);
	return (0);
}